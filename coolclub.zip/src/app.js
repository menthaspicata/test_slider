import './js/slick';
import './js/slider';

import './scss/main.scss'
